var express = require("express");
var bodyParser = require("body-parser");
var cors = require("cors");
var model = require('./model/db.js');  //

var app = express();

// serves files in public folder
app.use(express.static('public'));
app.use(cors());
// NB:: this must be included to get JSON content sent with requests
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

///////////////////////////////////////////////////////////////////////////////////////////

// REST API /players GET route
// app.route('/players/')
//   .get(function (req, res) {  
//     model.getPlayers(req, res);
//   })


///////////////////////////////////////////////////////////////////////////////////////////

// setup REST API /team route VERBS - GET, POST, PUT, DELETE
app.route('/players')
  .get(function (req, res) {
    res.status(200);
    model.getPlayers(req, res);
    console.log(req.params.name);
  })
  .post(function (req, res) { // add
    // add solution here
  })
  .put(function (req, res) { // edit
    // add solution here
  })
  .delete(function (req, res) { // delete
    // add solution here
  });

  app.route('/players/:player_id')
  .get(function (req, res) {
    res.status(200);
    model.getPlayerID(req, res);
    console.log(req.params.name);
  })
  .post(function (req, res) { // add
    // add solution here
  })
  .put(function (req, res) { // edit
    // add solution here
  })
  .delete(function (req, res) { // delete
    // add solution here
  });

  ////////////////////////////////////////////////////////////////

//---------------TEAMS
app.route('/teams')
  .get(function (req, res) {
    res.status(200);
    model.getTeam(req, res);
    console.log(req.params.id);
  })
  .post(function (req, res) { // add
    // add solution here
  })
  .put(function (req, res) { // edit
    // add solution here
  })
  .delete(function (req, res) { // delete
    // add solution here
  });

  app.route('/teams/:id')
  .get(function (req, res) {
    res.status(200);
    model.getTeamID(req, res);
    console.log(req.params.name);
  })
  .post(function (req, res) { // add
    // add solution here
  })
  .put(function (req, res) { // edit
    // add solution here
  })
  .delete(function (req, res) { // delete
    // add solution here
  });

    ////////////////////////////////////////////////////////////////

//--------------MATCHES
app.route('/matches')
  .get(function (req, res) {
    res.status(200);
    model.getMatches(req, res);
    console.log(req.params.match_date);
  })
  .post(function (req, res) { // add
    // add solution here
  })
  .put(function (req, res) { // edit
    // add solution here
  })
  .delete(function (req, res) { // delete
    // add solution here
  });

  ////////////////////////////////////////////////////////////////

//--------------MATCHEVENTS
app.route('/matchevents')
  .get(function (req, res) {
    res.status(200);
    model.getMatchEvents(req, res);
    console.log(req.params.event_name);
  })
  .post(function (req, res) { // add
    // add solution here
  })
  .put(function (req, res) { // edit
    // add solution here
  })
  .delete(function (req, res) { // delete
    // add solution here
  });

    ////////////////////////////////////////////////////////////////

//--------------STADIUM
app.route('/stadiums')
  .get(function (req, res) {
    res.status(200);
    model.getStadium(req, res);
    console.log(req.params.name);
  })
  .post(function (req, res) { // add
    // add solution here
  })
  .put(function (req, res) { // edit
    // add solution here
  })
  .delete(function (req, res) { // delete
    // add solution here
  });

  ////////////////////////////////////////////////////////////////
  app.route('/players/5503')
  .get(function (req, res) {
    res.status(200);
    model.getMessi(req, res);
    console.log(req.params.name);
  })
  .post(function (req, res) { // add
    // add solution here
  })
  .put(function (req, res) { // edit
    // add solution here
  })
  .delete(function (req, res) { // delete
    // add solution here
  });
  ////////////////////////////////////////////////////////////////
  app.route('/playerstats/5503')
  .get(function (req, res) {
    res.status(200);
    model.getMessiStats(req, res);
    console.log(req.params.name);
  })
  .post(function (req, res) { // add
    // add solution here
  })
  .put(function (req, res) { // edit
    // add solution here
  })
  .delete(function (req, res) { // delete
    // add solution here
  });

  ////////////////////////////////////////////////////////////////
  app.route('/playerstats/:id')
  .get(function (req, res) {
    res.status(200);
    model.getPlayerStats(req, res);
    console.log(req.params.name);
  })
  .post(function (req, res) { // add
    // add solution here
  })
  .put(function (req, res) { // edit
    // add solution here
  })
  .delete(function (req, res) { // delete
    // add solution here
  });


  app.route('/shots/5503')
  .get(function (req, res) {
    res.status(200);
    model.getShots(req, res);
    console.log(req.params.name);
  })
  .post(function (req, res) { // add
    // add solution here
  })
  .put(function (req, res) { // edit
    // add solution here
  })
  .delete(function (req, res) { // delete
    // add solution here
  });

  app.route('/passes/5503')
  .get(function (req, res) {
    res.status(200);
    model.getPasses(req, res);
    console.log(req.params.name);
  })
  .post(function (req, res) { // add
    // add solution here
  })
  .put(function (req, res) { // edit
    // add solution here
  })
  .delete(function (req, res) { // delete
    // add solution here
  });

  app.route('/home')
  .get(function (req, res) {
    res.status(200);
    model.getSummary(req, res);
    console.log(req.params.name);
  })
  .post(function (req, res) { // add
    // add solution here
  })
  .put(function (req, res) { // edit
    // add solution here
  })
  .delete(function (req, res) { // delete
    // add solution here
  });
var myServer = app.listen(3000, function () {
  console.log("Server listening on port 3000");
});
