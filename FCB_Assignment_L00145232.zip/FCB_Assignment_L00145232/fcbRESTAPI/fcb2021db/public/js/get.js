$("document").ready(function () {

    $("#GETbtn").click(function () {

        console.log(`http://localhost:3000/players`);
        $.get(`http://localhost:3000/players`, function (data) {
            console.log(data);
            $("#response").text(data);
        });

    });
    /////////////////
    $("#GETteam").click(function () {

        console.log(`http://localhost:3000/teams`);
        $.get(`http://localhost:3000/teams`, function (data) {
            console.log(data);
            $("#response").text(data);
        });

    });
    ////////////////
    $("#GETstadium").click(function () {

        console.log(`http://localhost:3000/stadiums`);
        $.get(`http://localhost:3000/stadiums`, function (data) {
            console.log(data);
            $("#response").text(data);
        });

    });
    ///////////
    $("#GETmatches").click(function () {

        console.log(`http://localhost:3000/matches`);
        $.get(`http://localhost:3000/matches`, function (data) {
            console.log(data);
            $("#response").text(data);
        });

    });
    ////////
    $("#GETmatchevent").click(function () {

        console.log(`http://localhost:3000/matchevents`);
        $.get(`http://localhost:3000/matchevents`, function (data) {
            console.log(data);
            $("#response").text(data);
        });

    });

       ////////
       $("#GETmessi").click(function () {

        console.log(`http://localhost:3000/players/5503`);
        $.get(`http://localhost:3000/players/5503`, function (data) {
            console.log(data);
            $("#response").text(data);
        });

    });

       ////////
       $("#GETmessistats").click(function () {

        console.log(`http://localhost:3000/playerstats/5503`);
        $.get(`http://localhost:3000/playerstats/5503`, function (data) {
            console.log(data);
            $("#response").text(data);
        });

    });

    

    $("#GETshots").click(function () {

        console.log(`http://localhost:3000/shots/5503`);
        $.get(`http://localhost:3000/shots/5503`, function (data) {
            console.log(data);
            $("#response").text(data);
        });

    });

    $("#GETpasses").click(function () {

        console.log(`http://localhost:3000/passes/5503`);
        $.get(`http://localhost:3000/passes/5503`, function (data) {
            console.log(data);
            $("#response").text(data);
        });

    });

    $("#GETsummary").click(function () {

        console.log(`http://localhost:3000/home`);
        $.get(`http://localhost:3000/home`, function (data) {
            console.log(data);
            $("#response").text(data);
        });

    });
});

