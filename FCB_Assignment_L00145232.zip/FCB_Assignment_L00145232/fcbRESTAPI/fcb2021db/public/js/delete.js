$("document").ready(function(){
    
    $("#DELETEbtn").click( function(){
        var id=$("#id").val();
        console.log(`http://localhost:3000/players`);
        $.ajax({
            url: `http://localhost:3000/players`,
            type: 'DELETE',            
            data: id,
            success: function(data) {
                $("#response").text(data);
            }
        });

    });
    
});

