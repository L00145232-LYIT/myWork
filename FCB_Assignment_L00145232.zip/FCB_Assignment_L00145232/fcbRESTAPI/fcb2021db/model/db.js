var mysql = require('mysql');

///////////////////////////////////////////////////////////////////////////////////////////

// Setup MySQL connection
// timezone is very NB

var connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'fcb2021',
  timezone: 'utc+0'
});

connection.connect(function (err) {
  if (err) throw err;
  console.log(`Sucessfully connected to MySQL database fcb2021`);
});

///////////////////////////////////////////////////////////////////////////////////////////

// GET /teams
exports.getPlayers = function (req, res) {

  connection.query(`SELECT p.player_id, p.name, p.team_id, t.name AS team_name FROM players p
  JOIN teams t ON t.id = p.team_id ORDER BY t.name`, function (err, rows, fields) {
    if (err) throw err;

    res.status(200);  // OK
    res.send(JSON.stringify(rows));
  });
}

exports.getTeam = function (req, res) {

  connection.query(`SELECT t.id, t.name, t.stadium_id, s.name AS stadium_name FROM teams t
   JOIN stadiums s ON t.stadium_id = s.id ORDER BY t.name `, function (err, rows, fields) {
    if (err) throw err;

    res.status(200);  // OK
    res.send(JSON.stringify(rows));
  });
}

exports.getMatches = function (req, res) {

  connection.query(`SELECT * FROM matches ORDER BY match_date `, function (err, rows, fields) {
    if (err) throw err;

    res.status(200);  // OK
    res.send(JSON.stringify(rows));
  });
}

exports.getMatchEvents = function (req, res) {

  connection.query(`SELECT * FROM matchevents`, function (err, rows, fields) {
    if (err) throw err;

    res.status(200);  // OK
    res.send(JSON.stringify(rows));
  });
}

exports.getStadium = function (req, res) {

  connection.query(`SELECT * FROM stadiums`, function (err, rows, fields) {
    if (err) throw err;

    res.status(200);  // OK
    res.send(JSON.stringify(rows));
  });
}
exports.getMessi = function (req, res) {

  connection.query(`SELECT * FROM players WHERE player_id=5503`, function (err, rows, fields) {
    if (err) throw err;

    res.status(200);  // OK
    res.send(JSON.stringify(rows));
  });
}

exports.getMessiStats = function (req, res) {

  var stats = 'SELECT event_name, COUNT(event_name) AS Amount FROM matchevents WHERE player_id=5503 GROUP BY event_name ORDER BY "Amount" DESC';

  connection.query(`${stats}  `,
    function (err, rows, fields) {
      if (err) throw err;

      res.status(200);  // OK
      res.send(JSON.stringify(rows));
    });
}

exports.getPlayerStats = function (req, res) {

  var stats = `SELECT event_name, COUNT(event_name) AS Amount FROM matchevents WHERE player_id=${req.params.id} GROUP BY event_name ORDER BY "Amount" DESC`;

  connection.query(`${stats}  `,
    function (err, rows, fields) {
      if (err) throw err;

      res.status(200);  // OK
      res.send(JSON.stringify(rows));
    });
}

// exports.getBarcaStats = function (req, res) {

//   var stats=`SELECT event_name, COUNT(event_name) AS Amount FROM matchevents WHERE team_id=217 GROUP BY event_name ORDER BY "Amount" DESC`;

//   connection.query(`${stats}  `,   
//   function (err, rows, fields) {
//     if (err) throw err;

//     res.status(200);  // OK
//     res.send(JSON.stringify(rows));
//   });
// }

exports.getShots = function (req, res) {

  connection.query(`SELECT * FROM matchevents WHERE player_id=5503 AND event_name="Shot"`, function (err, rows, fields) {
    if (err) throw err;

    res.status(200);  // OK
    res.send(JSON.stringify(rows));
  });
}

exports.getPasses = function (req, res) {

  connection.query(`SELECT * FROM matchevents WHERE player_id=5503 AND event_name="Pass"`, function (err, rows, fields) {
    if (err) throw err;

    res.status(200);  // OK
    res.send(JSON.stringify(rows));
  });
}

exports.getSummary = function (req, res) {

  var summary = `SELECT match_date,
  (SELECT COUNT(*) FROM matches ) as Played,
  (SELECT COUNT(*) FROM matches WHERE home_team_id=217) as HG,
  (SELECT COUNT(*) FROM matches WHERE away_team_id=217) as AG,
  (SELECT COUNT(*) FROM matches WHERE home_team_id=217 AND home_score > away_score) as HW,
  (SELECT COUNT(*) FROM matches WHERE away_team_id=217 AND home_score < away_score) as AW,
  (SELECT COUNT(*) FROM matches WHERE home_team_id=217 AND home_score < away_score) as HL,
  (SELECT COUNT(*) FROM matches WHERE away_team_id=217 AND home_score > away_score) as AL,
  (SELECT COUNT(*) FROM matches WHERE home_team_id=217 AND home_score = away_score) as HD,
  (SELECT COUNT(*) FROM matches WHERE away_team_id=217 AND home_score = away_score) as AD,
  (SELECT COUNT(*) FROM matches WHERE home_team_id=217 AND home_score > away_score OR away_team_id=217 AND home_score < away_score) as W,
  (SELECT COUNT(*) FROM matches WHERE home_team_id=217 AND home_score = away_score OR away_team_id=217 AND home_score = away_score) as D,
  (SELECT COUNT(*) FROM matches WHERE home_team_id=217 AND home_score < away_score OR away_team_id=217 AND home_score > away_score) as L,
  (SELECT SUM(home_score) FROM matches WHERE home_team_id=217) as HGF,
  (SELECT  SUM(away_score) FROM matches WHERE home_team_id=217) as HGA,
  (SELECT SUM(away_score) FROM matches WHERE away_team_id=217) as AGF,
  (SELECT SUM(home_score) FROM matches WHERE away_team_id=217) as AGA
FROM matches GROUP BY match_date=""`;

  connection.query(`${summary}; `, function (err, rows, fields) {
    if (err) throw err;

    res.status(200);  // OK
    res.send(JSON.stringify(rows));
  });
}
// GET /team/ID
exports.getTeamID = function (req, res) {

  connection.query(`SELECT * FROM teams WHERE id=${req.params.id}`, function (err, rows, fields) {
    if (err) throw err;

    res.status(200);  // OK
    res.send(JSON.stringify(rows));
  });
}

exports.getPlayerID = function (req, res) {

  connection.query(`SELECT * FROM players WHERE player_id=${req.params.player_id}`, function (err, rows, fields) {
    if (err) throw err;

    res.status(200);  // OK
    res.send(JSON.stringify(rows));
  });
}
