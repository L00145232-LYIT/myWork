import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Team } from '../admin/teams';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
url = 'http://localhost:3000/teams/';
  constructor(private httpClient: HttpClient) {

  }
  getStadiums() {
    return this.httpClient.get<Team[]>(this.url);
  }

  getStadium(team: Team) {
    let geturl = `${this.url}${team.id}`;
    return this.httpClient.get<Team[]>(geturl);
  }

  updateStadium(update: Team) {
    return this.httpClient.put<Team[]>(`${this.url}/${update.stadium_name}`,update);
  }
}