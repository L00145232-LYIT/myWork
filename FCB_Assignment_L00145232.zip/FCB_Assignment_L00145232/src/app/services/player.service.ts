import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Player } from '../players/player';
import { PlayerStats } from '../playerstats/playerstats';
@Injectable({
  providedIn: 'root'
})
export class PlayerService {
url = 'http://localhost:3000/players/';
urlstats = 'http://localhost:3000/playerstats/';
  constructor(private httpClient: HttpClient) {

  }
  getPlayers() {
    return this.httpClient.get<Player[]>(this.url);
  }

  getPlayer(player: Player) {
    let geturl = `${this.url}${player.player_id}`;
    return this.httpClient.get<Player[]>(geturl);
  }

  getPlayerStats(player: Player) {
    let geturl = `${this.urlstats}${player.player_id}`;
    return this.httpClient.get<PlayerStats[]>(geturl);
  }



}
