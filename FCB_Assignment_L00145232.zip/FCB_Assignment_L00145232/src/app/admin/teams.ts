export interface Team{
    id: number;
    name: String;
    stadium_id: number;
    stadium_name: String;
  }