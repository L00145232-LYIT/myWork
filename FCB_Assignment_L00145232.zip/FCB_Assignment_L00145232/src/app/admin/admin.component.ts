import { Component, OnInit } from '@angular/core';
import { AdminService } from '../services/admin.service';
import { Team } from './teams';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
team : Team[]=[];

  constructor(service: AdminService) {

    service.getStadiums().subscribe(response => {
      console.log(response);
      this.team = response;
      
    })


  }

  ngOnInit(): void {

  }

}


