import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { TeamsComponent } from './teams/teams.component';
import { PlayersComponent } from './players/players.component';
import { MatchesComponent } from './matches/matches.component';
import { FcbstatsComponent } from './fcbstats/fcbstats.component';
import { AdminComponent } from './admin/admin.component';
import { NavbarComponent } from './navbar/navbar.component';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PlayerstatsComponent } from './playerstats/playerstats.component';
import { UpdateComponent } from './update/update.component';
import { AdminService } from './services/admin.service';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    TeamsComponent,
    PlayersComponent,
    MatchesComponent,
    FcbstatsComponent,
    AdminComponent,
    NavbarComponent,
    PlayerstatsComponent,
    UpdateComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {
        path:'',
        component: HomeComponent
      },
      {
        path:'teams',
        component: TeamsComponent
      },
      {
        path:'players',
        component: PlayersComponent
      },
      {
        path:'matches',
        component: MatchesComponent
      },
      {
        path:'fcbstats',
        component: FcbstatsComponent
      },
      {
        path:'admin',
        component: AdminComponent
      },
      {
        path:'playerstats/:id',
        component: PlayerstatsComponent
      },
      {
        path:'admin/:id',
        component: UpdateComponent
      }
      
    ]),
    BrowserAnimationsModule
  ],
  providers: [AdminService],
  bootstrap: [AppComponent]
})
export class AppModule { }
