import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fcbstats',
  templateUrl: './fcbstats.component.html',
  styleUrls: ['./fcbstats.component.css']
})
export class FcbstatsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
