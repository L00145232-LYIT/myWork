import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FcbstatsComponent } from './fcbstats.component';

describe('FcbstatsComponent', () => {
  let component: FcbstatsComponent;
  let fixture: ComponentFixture<FcbstatsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FcbstatsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FcbstatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
