import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Team } from '../admin/teams';
import { ActivatedRoute } from '@angular/router';
import { AdminService } from '../services/admin.service';
import { Stadium } from './stadium';
@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  update: Team = { "id": 0, "name": "", "stadium_id": 0, "stadium_name": "" };
  newName: Stadium[]=[];
  constructor(private route: ActivatedRoute, private service: AdminService, ) {
    route.paramMap
      .subscribe(params => {
        console.log(params);
        let id = parseInt(params.get("id") || '');
        let sid = parseInt(params.get("stadium_id") || '');
        let name = params.get("name") || "";
        let stadium_name = params.get("stadium_name") || "";
        let update: Team = { "id": id, "name": name, "stadium_id": sid, "stadium_name": stadium_name };
        service.getStadium(update)
          .subscribe(response => {
            console.log(response);
            //this.update=response;
          })
      })

  
      
  }

  ngOnInit(): void {
  }

}
