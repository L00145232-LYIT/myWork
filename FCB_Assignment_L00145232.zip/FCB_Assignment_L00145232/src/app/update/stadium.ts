export interface Stadium{
    id: Number;
    name: String;
  }