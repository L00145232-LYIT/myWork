import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { PlayerService } from '../services/player.service';
import { Player } from './player';

@Component({
  selector: 'app-players',
  templateUrl: './players.component.html',
  styleUrls: ['./players.component.css']
})
export class PlayersComponent implements OnInit {
  players : Player[]=[];
 
  constructor(service: PlayerService) {

    service.getPlayers().subscribe(response => {
      console.log(response);
      this.players = response;
      
    })

  }
   
  
  ngOnInit(): void {
  }

}
