export interface Player{
  player_id: number;
  name: String;
  team_id:number;
  team_name:String;
}