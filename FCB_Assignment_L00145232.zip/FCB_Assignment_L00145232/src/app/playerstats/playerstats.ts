export interface PlayerStats{
    event_name: String;
    Amount: Number;
  }