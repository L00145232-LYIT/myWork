import { Component, OnInit } from '@angular/core';
import { PlayerStats } from './playerstats';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Player } from '../players/player';
import { PlayerService } from '../services/player.service';
@Component({
  selector: 'app-playerstats',
  templateUrl: './playerstats.component.html',
  styleUrls: ['./playerstats.component.css']
})
export class PlayerstatsComponent implements OnInit {
  playerStats: PlayerStats[] = [];
  player: Player [] =[];
  update: Player = {"name":"","player_id":0,"team_id":0,"team_name":""};

  constructor(private httpClient: HttpClient, private route:ActivatedRoute , service : PlayerService) {
    // route.paramMap
    // .subscribe(params => {
    //   console.log(params);
    //   let player_id = parseInt(params.get("player_id") || '');
  

    //   let update: Player = {"name":"","player_id":player_id,"team_id":0,"team_name":"" };
    //   service.getPlayer(update)
    //     .subscribe(response => {
    //       console.log(response);
    //     })
        this.httpClient.get<PlayerStats[]>(`http://localhost:3000/playerstats/5503`)
        .subscribe(response =>{
          console.log(response);
          this.playerStats=response;
          
        })
    // })
   
  }

  ngOnInit(): void {
  }

}
