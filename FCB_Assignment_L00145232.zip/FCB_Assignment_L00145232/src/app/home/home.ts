export interface Home{
   Played: Number;
   W: Number,
   D: Number,
   L: Number,
   HW: Number,
   HD: Number,
   HL: Number,
   HGF: Number,
   HGA: Number,
   AW: Number,
   AD: Number,
   AL: Number,
   AGF: Number,
   AGA: Number

  }