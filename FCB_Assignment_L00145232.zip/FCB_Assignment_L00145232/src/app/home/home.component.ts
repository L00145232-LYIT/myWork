import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Home } from './home';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  home : Home[]=[];
  constructor(private httpClient: HttpClient) {
   
    this.httpClient.get<Home[]>('http://localhost:3000/home/')
    .subscribe(response =>{
      console.log(response);
      this.home=response;
      
    })
  }



  ngOnInit(): void {
  }

}
