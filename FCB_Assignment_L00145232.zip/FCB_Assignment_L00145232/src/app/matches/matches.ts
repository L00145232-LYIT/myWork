export interface Matches {
    match_id: number;
    match_date: number;
    season_name: number;
    home_team_id: number;
    home_team_name: String;
    home_manager_name: String;
    away_team_id: number;
    away_team_name: String;
    away_manager_name: String;
    home_score: number;
    away_score: number;
    stadium_id: number;
    stadium_name: String;
}