import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import * as _ from 'underscore';
import { Matches } from './matches';
@Component({
  selector: 'app-matches',
  templateUrl: './matches.component.html',
  styleUrls: ['./matches.component.css']
})
export class MatchesComponent implements OnInit {
  match: Matches[] = [];
  constructor(private httpClient: HttpClient) {
    this.httpClient.get<Matches[]>('http://localhost:3000/matches/')
      .subscribe(response => {
        console.log(response);
        this.match = response;
        // if (document.getElementById("home")?.click()) {
        //   console.log("home clicked");
          
        //    this.match = this.home();
        // }
        // else if (document.getElementById("away")?.click()) {
        //    this.match = this.away();
        // }
        // else {
        //   this.match = response;
        // }
   
      })

  }

  home() {
    console.log("home games");
    console.log(_.where(this.match, { home_team_id: 217 }));

    return _.where(this.match, { home_team_id: 217 });

  }

  away() {
    console.log("away games");
    console.log(_.where(this.match, { away_team_id: 217 }));
    return _.where(this.match, { away_team_id: 217 });
  }

  all() {
    console.log("all");

    location.reload();
  }


  ngOnInit(): void {
  }

}


