console.log("Welcome Back");
for (let index = 0; index < 5; index++) {
    console.log('Gerard is going for a coffee');
}
