let student = [
    { name: 'Fred', age: 21 },
    { name: 'Mary', age: 19 },
    { name: 'Jane', age: 22 },
    { name: 'John', age: 18 },
    { name: 'Jack', age: 20 }

]
var rand = student[Math.floor(Math.random() * student.length)];
const students = new Promise(
    function (resolve, reject) {
      if (Math.random() > 0.4) {
        resolve();
      }
      else {
        reject();
      }
    });
  
    students.then(() => {
    console.log(rand);
  }).then(() => {
    console.log('pass');
  }).catch(() => {
    console.log('fail');
  
  });