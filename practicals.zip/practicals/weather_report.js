
const weather = new Promise(
  function (resolve, reject) {
    if (Math.random() > 0.6) {
      resolve();
    }
    else {
      reject();
    }
  });

weather.then(() => {
  console.log('sunny');
}).then(() => {
  console.log('day for the beach');
}).catch(() => {
  console.log('rainy');

});