const express = require('express');
const app = express();
var bodyParser = require('body-parser')
const port = 3000;

app.use('/assets', express.static(__dirname + '/public'));
app.use(bodyParser.urlencoded({ extended: false }));


app.get('/form', function (req, res)  {
    res.sendFile(__dirname+'/form.html');
    console.log(__dirname);
} );

app.get('/addition', function (req, res)  {
    res.sendFile(__dirname+'/addition.html');
    console.log(__dirname);
} );

app.post('/showSum', function(req, res) {
    console.log(req.body);
    res.send(`Your sum is ${req.body.num1} + ${req.body.num2} + ${req.body.num3} `)
 
});

app.post('/showName', function(req, res) {
    console.log(req.body);
   // res.send('no body parser')
    res.send(`hi ${req.body.firstName} ${req.body.lastName},your password is ${req.body.pwd}`); 
});


// at end catch route errors 
app.use(function(req, res){
    res.send('<h1>404 error</h1>')
});


app.listen(port, function () {
     console.log(`Example app listening on port ${port}!`);
});

// app.get('/theAttic', function(req, res) {
//    //res.send('Still cold in this attic')
//     res.sendFile(__dirname + "/form.html")
// })

// app.get('/myPic', function(req, res) {
//     console.log(__dirname + '/assets/images/logo.png');
    
//     res.sendFile(__dirname + '/assets/images/logo.png');
// });

// // passing in parameters form the address bar
// app.get('/person/:tel/:email', function(req, res) {
//     console.log(req.params.tel);
//     res.send(`My telphone number is ${req.params.tel}  email is ${req.params.email}`);
// });


// // display a form to enter a name
// app.get('/addName',  function(req, res){
//     res.sendFile(__dirname + '/index.html');
// });

// yyy
