let fs = require('fs');
let readlineSync = require('readline-sync');

let dataBuffer = fs.readFileSync(__dirname + '/questions.json');
//let studentJSON = JSON.stringify(dataBuffer.toString());

//console.log(`The JSON data in buffer = ${dataBuffer}`);

//const dataJSON = dataBuffer.toString();

var counter;
var name = readlineSync.question('May I have your name? ');
console.log(name);
const questionObj = JSON.parse(dataBuffer);
for(i=0;i <15;i++){
  
console.log(`${questionObj.quiz[i].question}`);
console.log(`a. ${questionObj.quiz[i].content[0]}`);
console.log(`b. ${questionObj.quiz[i].content[1]}`);
console.log(`c. ${questionObj.quiz[i].content[2]}`);
console.log(`d. ${questionObj.quiz[i].content[3]}`);
console.log(`answer  = ${questionObj.quiz[i].correct}`);
var answer = readlineSync.question('what is your answer? ');
if(answer!=questionObj.quiz[i].correct) {
    counter=i+1;
    console.log(`${name} score is ${counter} out of 15` );
    console.log(`YOUR FINAL SCORE IS ${counter}`);
    break;
}else{
    counter=i+1;
    console.log(`${name} score is ${counter} out of 15` );
    continue;

}
}
console.log(counter);
console.log(name);




quizJSON = JSON.stringify(questionObj)
fs.writeFileSync('questions.json', quizJSON);
