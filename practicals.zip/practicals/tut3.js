var readlineSync = require('readline-sync'),
 chalk = require('chalk');
console.log(chalk.blue("node games compendium"));
console.log(chalk.blue("====================="));
animals = [chalk.red('play your cards right'), chalk.red('who wants to be a pointaire'), 
chalk.red('mystery game'), chalk.red('player pts total')],
index = readlineSync.keyInSelect(animals, 'Which animal?');
console.log(`Ok, ${animals[index]} is your option.`);