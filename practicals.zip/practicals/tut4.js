// var fahToCel = function (val){
//     val=-40;
//     x=val*9/5+32;
//     return x;

// }
// var celToFah = function (val){
//     val=-40;
//     x=(val-32)*5/9;
//     return x;

// }
var fahrenheitToCelsius = require('fahrenheit-to-celsius');
var celsiusToFahrenheit = require('celsius-to-fahrenheit');
console.log(fahrenheitToCelsius(0));
console.log(celsiusToFahrenheit(0));
