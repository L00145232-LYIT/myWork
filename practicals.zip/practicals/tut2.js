// Load local, core or 3rd party modules with require
var _ = require('lodash');
const chalk = require('chalk');
var figlet = require('figlet');

var readlineSync = require("readline-sync");

var week = ['mon', 'tue', 'wed', 'thur', 'fri'];
var name = 'joe mc blogg';
var weekend = ['sat', 'sun'];
var prices = [12.1, 5, 34, 6.23, 21.6, 3.14, 6, 9.99];
var costs = [1.1, 2.5, 9.99, 6.23, 5, 3.14, 6, 0.99];

var webPage = 'https://www.rte.ie/sport/results/rugby/world-cup/11421/report-2661652/'
var longText = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor' +
    'incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis' +
    ' nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.' +
    ' Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore' +
    ' eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt ' +
    ' in culpa qui officia deserunt mollit anim id est laborum.';



var books = [{
        title: "JavaScript Objects",
        author: "Fred Flintstone",
        price: 9.99
    },
    {
        title: "Node.js for cavemen",
        author: "Barney Rubble",
        price: 21.99
    },
    {
        title: "Node.js in Five minutes",
        author: "Mary Smity",
        price: 11.99
    }
];

console.log(chalk.red(`Question 1`));
console.log(`1. a`);
console.log(_.upperCase(name));
console.log(`1. b`);
console.log(_.truncate(longText, { 'length': 30 } ) );
var res = _.split(webPage,"/");
console.log(`1. c`);
var res = _.split(webPage,"/");
console.log(` ${res}`);
console.log(_.split(webPage, '/', 6));


console.log(`Question 2`);
console.log(`2. a`);
let myCharArray = _.split('Lorem ipsum', '');
myCharArray.forEach(element => {
    console.log("char = " + element);
});

// concatenate the week and weekend arrays
let myWeek = _.union(week, weekend);
// remove tue and thur from the array
console.log(_.pull(week, 'tue', 'thur') );

console.log(_.union([2, 332.2, 56, 76, ], [1, 2, 34, 5, 3,3]));
let newArray = _.union([2, 32.2, 56, 76, ], [1, 2, 34, 5, 3,3]);
_.pull(newArray, 32.2, 76, 34);
console.log(newArray);

var other = _.concat(prices, costs);
console.log(other);
let total = 0;
_.forEach(other, function(item) {
    total += item;
});
console.log(`One way to get the total ${total}`);
console.log(`Is this a better way ${_.sum(other)}`);
console.log(`The average price is `);
console.log(`The average cost was ${_.mean(other)} `);
console.log(`is 5 in prices array ${_.includes(prices, 15)}`);

var lib = _.orderBy(books, 'price');

_.forEach(lib, function(element) {
    console.log(`${element.title} costs ${element.price}`);
})

console.log(chalk.green(
    'I am a green line ' +
    chalk.blue.underline.bold('with a blue substring') +
    ' that becomes green again!'
));


figlet('Main Menu', function(err, data) {
    if (err) {
        console.log('Something went wrong...');
        console.dir(err);
        return;
    }
    console.log(data)
});

// var userName = readlineSync.question('May I have your name? ');
// console.log('Hi ' + userName + '!');

var readlineSync = require('readline-sync'),
  animals = ['Lion', 'Elephant', 'Crocodile', 'Giraffe', 'Hippo'],
  index = readlineSync.keyInSelect(animals, 'Which animal?');
console.log('Ok, ' + animals[index] + ' goes to your room.');

