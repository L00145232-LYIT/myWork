var http = require('http');
let readlineSync = require('readline-sync');
let _ = require('lodash');
chalk = require('chalk');
let randomPort = _.random(3000, 4000);
let arrayHtml = ['about.html', 'college.html', 'contacts.html', 'help.html', 'index.html', 'student.html']


do {

    var index = readlineSync.keyInSelect(arrayHtml, 'Select option?');



    switch (index) {
        case 0: // view this file
            http.createServer(function (request, response) {
                response.writeHead(200, { 'Content-Type': 'text/html' });
                console.log('about');
                var myPage = fs.readlineSync('about.html', 'utf8');
                response.write(myPage);
                response.end('<h1>Goodbye!</h1>')
            }).listen(randomPort);
            break;
        case 1:
            http.createServer(function (request, response) {
                response.writeHead(200, { 'Content-Type': 'text/html' });
                console.log('college');
                var myPage = fs.readlineSync('college.html', 'utf8');
                response.write(myPage);
                response.end('<h1>Goodbye!</h1>')
            }).listen(randomPort);
            break;
        case 2:
            http.createServer(function (request, response) {
                response.writeHead(200, { 'Content-Type': 'text/html' });
                console.log('contacts');
                var myPage = fs.readlineSync('contacts.html', 'utf8');
                response.write(myPage);
                response.end('<h1>Goodbye!</h1>')
            }).listen(randomPort);
            break;
        case 3:
            http.createServer(function (request, response) {
                response.writeHead(200, { 'Content-Type': 'text/html' });
                console.log('help');
                var myPage = fs.readlineSync('help.html', 'utf8');
                response.write(myPage);
                response.end('<h1>Goodbye!</h1>')
            }).listen(randomPort);
            break;
        case 4:
            http.createServer(function (request, response) {
                response.writeHead(200, { 'Content-Type': 'text/html' });
                console.log('index');
                var myPage = fs.readlineSync('index.html', 'utf8');
                response.write(myPage);
                response.end('<h1>Goodbye!</h1>')
            }).listen(randomPort);
            break;
        case 5:
            http.createServer(function (request, response) {
                response.writeHead(200, { 'Content-Type': 'text/html' });
                console.log('student');
                var myPage = fs.readlineSync('student.html', 'utf8');
                response.write(myPage);
                response.end('<h1>Goodbye!</h1>')
            }).listen(randomPort);
            break;

        default:
            console.log('invalid link');
    }

    console.log(`Server running at http://127.0.0.1:${randomPort}/`);
} while (index >= 0);
