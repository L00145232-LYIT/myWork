const express = require('express');

const app = express();

const port = 3000;



app.get('/', function (req, res) {
    res.send('<h1>Hello World!!!</h1><h2>scripting form is in main folder</h2>');
    console.log(__dirname);
});



app.get('/about', function (req, res) {
    res.send('<h3> this is the about message</h3>')
});



app.listen(port, function () {
    console.log(`Example app listening on port ${port}!`);
});
