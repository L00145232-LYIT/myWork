var tmp=require('details.js');

var fahToCel = function(val){
    x = val * 9/5+32;
    return x;
}

var celToFah = function (val){
    x = (val-32)*5/9;
    return x;
}