var http = require('http');

http.createServer(function (request, response) {
    response.writeHead(200, { 'Content-Type': 'text/html' });
    if(request.url === '/about'){
        response.end('<h1>About Page</h1>');
    }
    else if(request.url === '/help'){
        response.end('<h1>Help Page</h1>');
    }
    else if(request.url === '/home'){
        response.end('<h1>Home Page</h1>');
    }
    
    // response.write('<h1>Help Me!!</h1><button>Click me</button>');
    else{
        response.end('<h1>ERROR 404</h1>');
    }
}).listen(8124);
console.log('Server running at http://127.0.0.1:8124/');