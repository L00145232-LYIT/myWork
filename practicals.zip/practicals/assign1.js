let _ = require('lodash');
let rlSync = require('readline-sync');
chalk = require('chalk');
let quiz = require('./quiz')

var options = [chalk.red('Play Pointaire Game'), chalk.green('Game Admin'), chalk.yellow('Top Five scores')];
do {
    console.log('\n\n\n');
    console.log(chalk.blue('Node Pointaire Game'));
    console.log(chalk.blue('====================='));
    var index = rlSync.keyInSelect(options, 'Select option?');
    var opt = parseInt(index);
   

    switch (index) {
        case 0: // view this file
            console.log('Play pointaire : ');      
            quiz.game();
         
            break;
        case 1:
            console.log('Pointaire Admin');
            quiz.menu();
            break;
        case 2: 
            console.log('Top Scores');
            quiz.score();
            break;
        default:
            console.log(chalk.red('other option selected'));
    }
} while (index >= 0);
