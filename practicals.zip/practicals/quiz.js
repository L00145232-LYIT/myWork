let readlineSync = require('readline-sync');
chalk = require('chalk');
let _ = require('lodash');
let fs = require('fs');

let dataBuffer = fs.readFileSync(__dirname + '/questions.json');
var questionObj = JSON.parse(dataBuffer);
let topScores = [
    { name: "Bob", score: 15, },
    { name: "Mary", score: 13, },
    { name: "Jane", score: 14, },
    { name: "Robert", score: 12, },
    { name: "Martina", score: 15 }

];

function pointaireGame(params) {

    var counter;//counts score
    var name = readlineSync.question(chalk.magenta('May I have your name? '));//prompts name
    var lives = 4;//lives left
    for (i = 1; i < 16; i++) {//random for loop that displays 15 random questions
        console.log(`------QUESTION ${i}------`)
        let randNum = _.random(0, 51);
        console.log(chalk.red(`${questionObj.quiz[randNum].question}`));
        console.log(chalk.red(`a. ${questionObj.quiz[randNum].content[0]}`));
        console.log(chalk.red(`b. ${questionObj.quiz[randNum].content[1]}`));
        console.log(chalk.red(`c. ${questionObj.quiz[randNum].content[2]}`));
        console.log(chalk.red(`d. ${questionObj.quiz[randNum].content[3]}`));
        console.log(chalk.red(`answer  = ${questionObj.quiz[randNum].correct}`));

     
        console.log(`YOU HAVE ${lives-1} LIFELINES LEFT`);
        var lifeline = readlineSync.question('do you want a lifeline [yes or no]? ');//yes if you want a lifeline or no if you just want to answer
        if (lifeline == "no") {
            var reject = readlineSync.question('what is your answer ? ');
            if (reject != questionObj.quiz[randNum].correct) {
                counter = i - 1;
                console.log(chalk.red(`YOUR FINAL SCORE IS ${counter}`));
                break;
            } else {
                counter = i;
                console.log(chalk.green(`${name} score is ${counter} out of 15`));
                continue;
            }
        }
        else if (lifeline == 'yes') {
            var option = readlineSync.question(' ask the audience[1], 50/50[2], or dial a friend[3] ');//1 = audience, 2=50/50, 3=friend
            lives--;
            if (lives == 0) {
                counter = i - 1;
                console.log(chalk.red(`YOUR FINAL SCORE IS ${counter}`));
                break;
            }
            if (option == 1) {
                let audience = _.random(0, 3);
                console.log(chalk.red(`the audience thinks it is ${questionObj.quiz[randNum].content[audience]}`));
                var crowd = readlineSync.question('what is your answer ? ');
                if (crowd != questionObj.quiz[randNum].correct) {
                    counter = i - 1;
                    console.log(chalk.red(`YOUR FINAL SCORE IS ${counter}`));
                    break;
                } else {
                    counter = i;
                    console.log(chalk.green(`${name} score is ${counter} out of 15`));
                    continue;
                }
            }
            else if (option == 2) {
                let fifty = _.random(0, 3);
                console.log(chalk.red(`its either ${questionObj.quiz[randNum].correct} or a.`));
                var half = readlineSync.question('what is your answer ? ');
                if (half != questionObj.quiz[randNum].correct) {
                    counter = i - 1;
                    console.log(chalk.red(`YOUR FINAL SCORE IS ${counter}`));
                    break;
                } else {
                    counter = i;
                    console.log(chalk.green(`${name} score is ${counter} out of 15`));
                    continue;
                }



            }
            else if (option == 3) {
                let friend = _.random(0, 3);
                console.log(chalk.red(`the friend thinks it is ${questionObj.quiz[randNum].content[friend]}`));
                var buddy = readlineSync.question('what is your answer ? ');
                if (buddy != questionObj.quiz[randNum].correct) {
                    counter = i - 1;
                    console.log(chalk.red(`YOUR FINAL SCORE IS ${counter}`));
                    break;
                } else {
                    counter = i;
                    console.log(chalk.green(`${name} score is ${counter} out of 15`));
                    continue;
                }


            }
            else {
                console.log('invalid option');
            }
        }
        else {
            console.log('invalid option');
        }
        var answer = readlineSync.question('what is your answer ? ');

        if (answer != questionObj.quiz[randNum].correct) {
            counter = i - 1;
            console.log(chalk.red(`YOUR FINAL SCORE IS ${counter}`));
            break;
        }
        else {
            counter = i;
            console.log(chalk.green(`${name} score is ${counter} out of 15`));
            continue;

        }
    }
    // console.log(counter);
    // console.log(name);
    Object.assign(topScores,//once quiz is over, you assign the persons name and score to the list
        {
            name: name,
            score: counter
        });
    // console.log(topScores);

} 2

function adminMenu() {
    var options = [chalk.green('Add'), chalk.green('Delete'), chalk.green('Edit'), chalk.green('view')];

    do {
        console.log('\n\n\n');
        console.log(chalk.green('Pointaire Admin Menu'));
        console.log(chalk.green('====================='));
        var index = readlineSync.keyInSelect(options, 'Select option?');
        switch (index) {
            case 0:


                console.log('ADDING QUESTION & ANSWER ');
                var quest = readlineSync.question(chalk.green('what is your new question?'));
                console.log(quest);
                var c1 = readlineSync.question(chalk.green('what is your first content[a]? '));
                var c2 = readlineSync.question(chalk.green('what is your second content[b]? '));
                var c3 = readlineSync.question(chalk.green('what is your third content[c]? '));
                var c4 = readlineSync.question(chalk.green('what is your fourth content[d]? '));
                var ans = readlineSync.question(chalk.green('what is your new answer[choose a..d]? '));
                let content = [c1, c2, c3, c4];
                questionObj.quiz.push(//adds new question to array
                    {
                        "question": quest,
                        "content": content,
                        "correct": ans
                    });

                break;
            case 1:
                console.log('DELETING QUESTION & ANSWER');
                var deleteQuestion = readlineSync.question(chalk.green(`Select a number from 1..${questionObj.quiz.length} to delete a question?`));
                questionObj.quiz.splice(deleteQuestion - 1, 1);//deletes selected question



                break;
            case 2:
                console.log('EDITING QUESTION & ANSWER');
                var chooseQuestion = readlineSync.question(chalk.green(`Select a number from 0..${questionObj.quiz.length - 1}  to edit a question?`));
                var editQ = readlineSync.question(chalk.green('what is your new question? '));
                var e1 = readlineSync.question(chalk.green('what is your first content[a]? '));
                var e2 = readlineSync.question(chalk.green('what is your second content[b]? '));
                var e3 = readlineSync.question(chalk.green('what is your third content[c]? '));
                var e4 = readlineSync.question(chalk.green('what is your fourth content[d]? '));
                var editAnswer = readlineSync.question(chalk.green('what is your new answer[choose a..d]? '));

                questionObj.quiz[chooseQuestion].question = editQ;
                questionObj.quiz[chooseQuestion].content[0] = e1;
                questionObj.quiz[chooseQuestion].content[1] = e2;
                questionObj.quiz[chooseQuestion].content[2] = e3;
                questionObj.quiz[chooseQuestion].content[3] = e4;
                questionObj.quiz[chooseQuestion].correct = editAnswer;
                fs.writeFileSync(__dirname + '/questions.json', JSON.stringify(questionObj, null, 2));//pastes updated question on questions.json

                break;
            case 3:
                console.log('VIEWING QUESTION & ANSWER');
                for (i = 0; i < questionObj.quiz.length; i++) {
                    console.log(`------QUESTION ${i + 1}------`);
                    console.log(chalk.green(`${questionObj.quiz[i].question}`));
                    console.log(chalk.green(`a. ${questionObj.quiz[i].content[0]}`));
                    console.log(chalk.green(`b. ${questionObj.quiz[i].content[1]}`));
                    console.log(chalk.green(`c. ${questionObj.quiz[i].content[2]}`));
                    console.log(chalk.green(`d. ${questionObj.quiz[i].content[3]}`));
                    console.log(chalk.green(`answer  = ${questionObj.quiz[i].correct}`));


                }
                break;
            default:
                console.log('other option selected');
        }
    } while (index >= 0);
}

function topScore() {


    console.log(topScores.sort(function (a, b) { return b.score - a.score }));//displays score from max to min


}

module.exports = {//imports functions to assign1.js
    score: topScore,
    game: pointaireGame,
    menu: adminMenu
}
