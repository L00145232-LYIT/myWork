const fs = require('fs-extra');
const readAllFiles = async () => {
    let theOutput = "";
    try {
        theOutput = await fs.readFile('mary.txt');
        theOutput += await fs.readFile('mary2.txt');
        theOutput += await fs.readFile('mary3.txt');
        theOutput += await fs.readFile('mary4.txt');
        console.log(theOutput);
    }
    catch (err) {
        console.log('error');
    }
}