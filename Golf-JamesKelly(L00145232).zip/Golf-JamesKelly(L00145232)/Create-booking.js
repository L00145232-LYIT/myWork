const sqlite3 = require('sqlite3');
const db = new sqlite3.Database('booking.sqlite');

db.serialize(() => {
    // Create  table
    db.run('DROP TABLE IF EXISTS booking');
    db.run('CREATE TABLE booking (name TEXT, time TEXT, date TEXT)');
    // add recs
    const stmt = db.prepare('INSERT INTO booking VALUES (?,?,?)');
    stmt.run('Joe Bloggs', '12:00', '04/19/2021');
    stmt.run('Patricia Murphy', '9:00', '04/19/2021');
    stmt.run('Andy Smith', '11:30', '04/19/2021');
    stmt.run('Alan Jones', '2:15', '04/19/2021');
    stmt.run('Mary Duncan', '3:15', '04/19/2021');

    stmt.finalize();
});

db.close();
