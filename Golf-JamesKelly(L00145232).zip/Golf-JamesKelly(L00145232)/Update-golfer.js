const sqlite3 = require('sqlite3');
const db = new sqlite3.Database('golf.sqlite');

db.run("UPDATE golf set email='with hold' WHERE age > 21", function (err, row) {
    if(err) { // do something
        console.log("Error : " + err);
    }
    else { // ok
      console.log("rows updated");
    }

});
db.close();
