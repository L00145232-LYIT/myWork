const sqlite3 = require('sqlite3');
const db = new sqlite3.Database('booking.sqlite');

module.exports.readTime = function () {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database('booking.sqlite');
        const queries = [];
        var count = 0;
        db.serialize(function () {

            db.each(`SELECT rowid as id, * FROM booking`, function (err, row) {
                queries[count++] = row;
                if (err) {
                    reject(err);
                }
            });
            db.close(function () {
                console.log('the result is now=' + queries.length);
                resolve(queries);
            });
        });
    });
}

module.exports.addBookings = function (bookingObj) {
    console.log('adding new booking');
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database('booking.sqlite');

        db.serialize(function () {
            const stmt = db.prepare('INSERT INTO booking VALUES (?,?,?)', function (err, row) {
                stmt.run(bookingObj.name, bookingObj.time, bookingObj.date);
                console.log(bookingObj.name);
                console.log(bookingObj.date);
                console.log(bookingObj.time);
                stmt.finalize();

                if (err) {
                    reject(err);
                    console.log('error');
                }
            });

            db.close(function () {
                console.log('resolved');
                resolve(bookingObj);
            });
        });
    });
}
module.exports.deleteBooking = function (deleteObj) {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database('booking.sqlite');

        db.serialize(function () {

            db.each("DELETE FROM booking WHERE " + deleteObj.booking, function (err, row) {

                if (err) {
                    reject(err);
                }
            });
            db.close(function () {

                resolve(deleteObj);
            });
        });
    });
}
module.exports.editBooking = function (editGolfObj) {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database('booking.sqlite');
        db.serialize(function () {

            db.run("UPDATE booking set date='" + editGolfObj.date + "', time='" + editGolfObj.time + "', name='" +
                editGolfObj.name + "' WHERE name = '" + editGolfObj.name + "'", function (err, row) {

                    if (err) {
                        reject(err);
                    }
                });
            db.close(function () {

                resolve(editGolfObj);
            });
        });

    });
}


module.exports.selectDate = function (dateObj) {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database('booking.sqlite');
        const queries = [];
        var count = 0;
        db.serialize(function () {

            db.each(`SELECT rowid as id, * FROM booking WHERE date='`+dateObj.date+`'`, function (err, row) {
                queries[count++] = row;
                if (err) {
                    reject(err);
                }
            });
            db.close(function () {
                console.log('the result is now=' + queries.length);
                resolve(queries);
            });
        });
    });
}