const sqlite3 = require('sqlite3');
const db = new sqlite3.Database('golf.sqlite');

db.run("DELETE FROM golf WHERE name ='Mr J Kelly'", function (err, row) {
    if(err) { // do something
        console.log("Error : " + err);
    }
    else { // ok
      console.log("rows deleted");
    }
});
db.close();
