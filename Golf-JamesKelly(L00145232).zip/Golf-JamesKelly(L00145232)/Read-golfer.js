const sqlite3 = require('sqlite3');
const db = new sqlite3.Database('golf.sqlite');

db.each("SELECT rowid AS id, * FROM golf", function (err, row) {
    console.log(`golf >  ${row.name},  ${row.email}, ${row.gender}, ${row.age} , ${row.handicap}`);
});
db.close();
