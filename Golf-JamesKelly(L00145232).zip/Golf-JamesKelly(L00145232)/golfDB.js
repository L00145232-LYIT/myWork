const sqlite3 = require('sqlite3');
const db = new sqlite3.Database('golf.sqlite');

module.exports.readGolfer = function () {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database('golf.sqlite');
        const queries = [];
        var count = 0;
        db.serialize(function () {

            db.each(`SELECT rowid as id, * FROM golf`, function (err, row) {
                queries[count++] = row;
                if (err) {
                    reject(err);
                }
            });
            db.close(function () {
                console.log('the result is now=' + queries.length);
                resolve(queries);
            });
        });
    });
}

module.exports.readBook = function () {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database('golf.sqlite');
        const queries = [];
        var count = 0;
        db.serialize(function () {

            db.each(`SELECT rowid as id, * FROM golf`, function (err, row) {
                queries[count++] = row;
                if (err) {
                    reject(err);
                }
            });
            db.close(function () {
                console.log('the result is now=' + queries.length);
                resolve(queries);
            });
        });
    });
}





module.exports.addGolfer = function (golfObj) {
    console.log('adding new golfer');
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database('golf.sqlite');

        db.serialize(function () {
            const stmt = db.prepare('INSERT INTO golf VALUES (?,?,?,?,?)', function (err, row) {
                stmt.run(golfObj.name, golfObj.email, golfObj.gender, golfObj.age, golfObj.handicap);
                console.log(golfObj.name + "\n" + golfObj.email + "\n" + golfObj.gender + "\n" + golfObj.age + "\n" + golfObj.handicap);

                stmt.finalize();

                if (err) {
                    reject(err);
                    console.log('error');
                }
            });

            db.close(function () {
                console.log('resolved');
                resolve(golfObj);
            });
        });
    });
}


module.exports.deleteGolfer = function (deleteGolfObj) {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database('golf.sqlite');
        db.serialize(function () {
            console.log("the golfer is" + deleteGolfObj.golfer);
            db.each("DELETE FROM golf WHERE name='" + deleteGolfObj.golfer + "'", function (err, row) {

                if (err) {
                    reject(err);
                }
            });
            db.close(function () {

                resolve(deleteGolfObj);
            });
        });

    });
}


module.exports.deleteAllBookName = function (deleteGolfObj) {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database('booking.sqlite');
        db.serialize(function () {
            console.log("the golfer is" + deleteGolfObj.golfer);
            db.each("DELETE FROM booking WHERE name='" + deleteGolfObj.golfer + "'", function (err, row) {

                if (err) {
                    reject(err);
                }
            });
            db.close(function () {

                resolve(deleteGolfObj);
            });
        });

    });
}

module.exports.editGolfer = function (editGolfObj) {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database('golf.sqlite');
        db.serialize(function () {
            
           db.run("UPDATE golf set email='"+editGolfObj.email+"', age='"+editGolfObj.age+
           "', handicap='"+editGolfObj.handicap+"', gender='"+editGolfObj.gender+"', name='"+
           editGolfObj.name+"' WHERE name = '"+  editGolfObj.name+ "'", function (err, row) {

                if (err) {
                    reject(err);
                }
            });
            db.close(function () {

                resolve(editGolfObj);
            });
        });

    });
}

module.exports.readMale = function () {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database('golf.sqlite');
        const queries = [];
        var count = 0;
        db.serialize(function () {

            db.each(`SELECT rowid as id, * FROM golf WHERE gender='male'`, function (err, row) {
                queries[count++] = row;
                if (err) {
                    reject(err);
                }
            });
            db.close(function () {
                console.log('the result is now=' + queries.length);
                resolve(queries);
            });
        });
    });
}

module.exports.readFemale = function () {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database('golf.sqlite');
        const queries = [];
        var count = 0;
        db.serialize(function () {

            db.each(`SELECT rowid as id, * FROM golf WHERE gender='female'`, function (err, row) {
                queries[count++] = row;
                if (err) {
                    reject(err);
                }
            });
            db.close(function () {
                console.log('the result is now=' + queries.length);
                resolve(queries);
            });
        });
    });
}

module.exports.readOther = function () {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database('golf.sqlite');
        const queries = [];
        var count = 0;
        db.serialize(function () {

            db.each(`SELECT rowid as id, * FROM golf WHERE gender='other'`, function (err, row) {
                queries[count++] = row;
                if (err) {
                    reject(err);
                }
            });
            db.close(function () {
                console.log('the result is now=' + queries.length);
                resolve(queries);
            });
        });
    });
}

module.exports.readHc10 = function () {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database('golf.sqlite');
        const queries = [];
        var count = 0;
        db.serialize(function () {

            db.each(`SELECT rowid as id, * FROM golf WHERE handicap <= 10`, function (err, row) {
                queries[count++] = row;
                if (err) {
                    reject(err);
                }
            });
            db.close(function () {
                console.log('the result is now=' + queries.length);
                resolve(queries);
            });
        });
    });
}

module.exports.readHc1120 = function () {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database('golf.sqlite');
        const queries = [];
        var count = 0;
        db.serialize(function () {

            db.each(`SELECT rowid as id, * FROM golf  WHERE handicap > 10 AND handicap < 20`, function (err, row) {
                queries[count++] = row;
                if (err) {
                    reject(err);
                }
            });
            db.close(function () {
                console.log('the result is now=' + queries.length);
                resolve(queries);
            });
        });
    });
}

module.exports.readHc20 = function () {
    return new Promise((resolve, reject) => {
        const db = new sqlite3.Database('golf.sqlite');
        const queries = [];
        var count = 0;
        db.serialize(function () {

            db.each(`SELECT rowid as id, * FROM golf  WHERE handicap >= 20`, function (err, row) {
                queries[count++] = row;
                if (err) {
                    reject(err);
                }
            });
            db.close(function () {
                console.log('the result is now=' + queries.length);
                resolve(queries);
            });
        });
    });
}