var express = require("express");
const bodyParser = require('body-parser');
var exphbs = require("express-handlebars");
var app = express();
const fs = require("fs");
const golfers = require("./golfDB");
const bookings = require("./bookingDB");

let buffer = fs.readFileSync(__dirname + "/golf.json");
let contactLst = JSON.parse(buffer);
const sqlite3 = require("sqlite3");
const db = new sqlite3.Database("golf.sqlite");

/* needed to access public assets */
app.use(express.static(__dirname + "/public"));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("node_modules/bootstrap/dist"));

app.engine("handlebars", exphbs());
app.set("view engine", "handlebars");


app.get("/", function (req, res) {
    res.render("index");
});

app.get("/golf", function (req, res) {
    golfers.readGolfer()
        .then(function (data) {
            res.render("read", { mygolfers: data });
        })
        .catch(function () {
            console.log("error");
        });
});

app.post("/golf", function (req, res) {
    golfers.readGolfer()
        .then(function (data) {
            res.render("read", { mygolfers: data });
        })
        .catch(function () {
            console.log("error");
        });
});


app.get("/time", function (req, res) {
    bookings.readTime()
        .then(function (data) {
            res.render("time", { mybook: data });
        })
        .catch(function () {
            console.log("error");
        });
});

app.post("/viewAllBook", function (req, res) {
    bookings.readTime()
        .then(function (data) {
            res.render("time", { mybook: data });
        })
        .catch(function () {
            console.log("error");
        });
});

app.post("/time", function (req, res) {
    bookings.readTime()
        .then(function (data) {
            res.render("time", { mybook: data });
        })
        .catch(function () {
            console.log("error");
        });
});
app.post("/date", function (req, res) {
    console.log(req.body);
    var date = {
        date: req.body.bookingdate,
    
    };
    bookings.selectDate(date)
        .then(function (data) {
            res.render("time", { mybook: data });
        })
        .catch(function () {
            console.log("error");
        });
   
});


app.get("/book", function (req, res) {
    golfers
        .readBook()
        .then(function (data) {
            res.render("bookings", { member: data });
        })
        .catch(function () {
            console.log("error");
        });
});
app.get("/delete", function (req, res) {

    golfers.readGolfer()
        .then(function (data) {
            res.render("delete", { member: data });
        })
        .catch(function () {
            console.log("error");
        });
});
app.get("/deleteBook", function (req, res) {
    bookings
        .readTime()
        .then(function (data) {
            res.render("deleteBook", { member: data });
        })
        .catch(function () {
            console.log("error");
        });
});
app.get("/about", function (req, res) {
    res.render("about", {
        company: "St.Johnston Golf Club",
        address: "Railway Road, St.Johnston, Co.Donegal",
        tel: +353861234567,
        email: "feedback@stgc.ie",
    });
});

app.post("/addBook", function (req, res) {
    // console.log("name" + req.body.name + "time" + req.body.time + "date" + req.body.date);

    console.log("member " + req.body.members);
    console.log("booking number " + req.body.bookingtime);
    console.log("date " + req.body.bookingdate);
    var bookingObj = {
        name: req.body.members,
        time: req.body.bookingtime,
        date: req.body.bookingdate
    };

    bookings.addBookings(bookingObj);
    res.render('addedBook');
});

app.post("/deletedBook", function (req, res) {
    // console.log("name" + req.body.name + "time" + req.body.time + "date" + req.body.date);

    console.log(req.body);
    console.log(req.body.deleteBook);
    var info = {
        booking: req.body.deleteBook
    }
    bookings.deleteBooking(info);
    res.render('deletedBook');
});

app.post("/deletedGolfer", function (req, res) {
    // console.log("name" + req.body.name + "time" + req.body.time + "date" + req.body.date);

    console.log(req.body);
    console.log(req.body.deleteMembers);
    var obj = {
        golfer: req.body.deleteMembers
    }
    golfers.deleteGolfer(obj);
    golfers.deleteAllBookName(obj);
    res.render('deletedGolfer');
});
app.post("/addMember", function (req, res) {
    console.log(req.body);
    var golf = {
        name: req.body.firstName,
        email: req.body.email,
        gender: req.body.gender,
        age: req.body.age,
        handicap: req.body.handicap,
    };
    console.log(golf);
    golfers.addGolfer(golf);
    res.render('addedGolfer');
})

app.get("/add", function (req, res) {
    res.render("add");
});

app.post("/edit", function (req, res) {
  
    golfers.readGolfer()
    .then(function (data) {
        res.render("edit", { guide: data });
    })
    .catch(function () {
        console.log("error");
    });
});

app.post("/editBook", function (req, res) {
    bookings
        .readTime()
        .then(function (data) {
            res.render("editBook", { member: data,
            guide:data });
        })
   



});

app.post("/editedBook", function (req, res) {
    console.log("member " + req.body.members);
    console.log("booking number " + req.body.bookingtime);
    console.log("date " + req.body.bookingdate);
    var bookingObj = {
        name: req.body.members,
        time: req.body.bookingtime,
        date: req.body.bookingdate
    };
    bookings.editBooking(bookingObj);
    res.render('editedBook');
});

app.post("/editedMember", function (req, res) {
    console.log(req.body);
    var golferEditObj = {
        name: req.body.firstName,
        email: req.body.email,
        gender: req.body.gender,
        age: req.body.age,
        handicap: req.body.handicap
    };
    golfers.editGolfer(golferEditObj);
    res.render('editedGolfer');
});

app.post("/male", function (req, res) {
    golfers.readMale()
        .then(function (data) {
            res.render("read", { mygolfers: data });
        })
        .catch(function () {
            console.log("error");
        });
});
app.post("/female", function (req, res) {
    golfers.readFemale()
        .then(function (data) {
            res.render("read", { mygolfers: data });
        })
        .catch(function () {
            console.log("error");
        });
});
app.post("/other", function (req, res) {
    golfers.readOther()
        .then(function (data) {
            res.render("read", { mygolfers: data });
        })
        .catch(function () {
            console.log("error");
        });
});
app.post("/hc10", function (req, res) {
    golfers.readHc10()
        .then(function (data) {
            res.render("read", { mygolfers: data });
        })
        .catch(function () {
            console.log("error");
        });
});
app.post("/hc1120", function (req, res) {
    golfers.readHc1120()
        .then(function (data) {
            res.render("read", { mygolfers: data });
        })
        .catch(function () {
            console.log("error");
        });
});
app.post("/hc20", function (req, res) {
    golfers.readHc20()
        .then(function (data) {
            res.render("read", { mygolfers: data });
        })
        .catch(function () {
            console.log("error");
        });
});
app.listen(3000, function (req, res) {
    console.log("server running on port 3000");
});