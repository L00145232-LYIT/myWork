const sqlite3 = require('sqlite3');
const db = new sqlite3.Database('booking.sqlite');

db.run("DELETE FROM booking WHERE date ='12:45'", function (err, row) {
    if(err) { // do something
        console.log("Error : " + err);
    }
    else { // ok
      console.log("rows deleted");
    }
});
db.close();
