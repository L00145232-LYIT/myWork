const sqlite3 = require('sqlite3');
const db = new sqlite3.Database('golf.sqlite');

db.serialize(() => {
  // Create  table
  db.run('DROP TABLE IF EXISTS golf');
  db.run('CREATE TABLE golf (name TEXT, email TEXT, gender TEXT, age INT, handicap INT)');
  // add recs
  const stmt = db.prepare('INSERT INTO golf VALUES (?,?,?,?,?)');
  stmt.run('Joe Bloggs', 'joebloggs@lyit.ie', 'male', 21, 10);
  stmt.run('Patricia Murphy','pmurphy@lyit.ie', 'female', 23, 20);
  stmt.run('Andy Smith', 'AndySmith@lyit.ie', 'male', 19, 23);
  stmt.run('Alan Jones', 'aj@lyit.ie', 'male', 23, 8);
  stmt.run('Mary Duncan', 'mary.duncan@lyit.ie', 'female', 43, 18);

  stmt.finalize();

  // db.each("SELECT rowid AS gender, name, email FROM golf" , function(err, row ) {
  //     console.log(`${row.gender}   name: ${row.name}  email: ${row.email}`);
  // });
});

db.close();
