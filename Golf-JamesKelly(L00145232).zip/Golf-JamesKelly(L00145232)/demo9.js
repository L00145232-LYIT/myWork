const sqlite3 = require('sqlite3');
const db = new sqlite3.Database('golf.sqlite');
var names = ['james', 'john', 'tony', 'mark', 'mary',
                          'joan','fred', 'simon'];

db.serialize(function() {
  db.run("CREATE TABLE lorem  (info TEXT)");

  const stmt = db.prepare("INSERT INTO lorem VALUES (?)");

  for (var i = 0; i < names.length ; i++) {
      stmt.run("Ipsum " + names[i]);
  }
  stmt.finalize();

  db.each("SELECT rowid AS id, info FROM lorem", function (err, row) {
      console.log(`${row.id}: ${row.info}`);
  });
});
db.close();
