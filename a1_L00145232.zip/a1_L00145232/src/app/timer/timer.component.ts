import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-timer',
  templateUrl: './timer.component.html',
  styleUrls: ['./timer.component.css']
})
export class TimerComponent implements OnInit {

  timerID: any;
  num: number = 5;
  start() {

    this.timerID = setInterval(() =>
      this.tick(), 1000)

  }

  reset() {
    this.num = 5;
    clearInterval(this.timerID);
  }
  stop() {
    clearInterval(this.timerID);
  }
  tick() {
    this.num = this.num - 1;
  }
  constructor() { }

  ngOnInit(): void {
  }

}
