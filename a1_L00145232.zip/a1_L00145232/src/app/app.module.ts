import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ColourPickerComponent } from './colour-picker/colour-picker.component';
import { TimerComponent } from './timer/timer.component';
import { ImageviewerComponent } from './imageviewer/imageviewer.component';
import { TeamsComponent } from './teams/teams.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    ColourPickerComponent,
    TimerComponent,
    ImageviewerComponent,
    TeamsComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
