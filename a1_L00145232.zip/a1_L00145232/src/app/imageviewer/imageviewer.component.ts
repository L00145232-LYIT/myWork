import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-imageviewer',
  templateUrl: './imageviewer.component.html',
  styleUrls: ['./imageviewer.component.css']
})
export class ImageviewerComponent implements OnInit {
  num: number = 1;

  next() {
    if (this.num >= 3)
      this.num = 1;
    else {
      this.num++;
    }
  }

  prev() {
    if (this.num <= 1)
      this.num = 3;
    else {
      this.num--;
    }
  }
  constructor() { }

  ngOnInit(): void {
  }

}
