export interface Teams {
    teamcode: String,
    name: String,
    stadium: String,
    capacity: number,
    latitude: number,
    longitude: number
}