import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Teams } from './teams';

@Component({
  selector: 'app-teams',
  templateUrl: './teams.component.html',
  styleUrls: ['./teams.component.css']
})
export class TeamsComponent implements OnInit {
team: Teams[]=[];
  constructor(private httpClient: HttpClient) { 
    this.httpClient.get<Teams[]>('http://localhost:3000/teams/')
    .subscribe(response =>{
      console.log(response);
      this.team=response;
      
    })
  }

  ngOnInit(): void {
  }

}
