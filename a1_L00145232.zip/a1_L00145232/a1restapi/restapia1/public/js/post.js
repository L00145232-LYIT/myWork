$("document").ready(function(){
    
    $("#POSTbtn").click( function(){
  
        
        $.post(`http://localhost:3000/players/`, 
             
                function(data){
                    $("#response").text(data);
                });

    });
    
});
