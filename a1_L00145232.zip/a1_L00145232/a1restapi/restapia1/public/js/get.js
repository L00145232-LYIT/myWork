
    /////////////////
    $("#GETteam").click(function () {

        console.log(`http://localhost:3000/teams`);
        $.get(`http://localhost:3000/teams`, function (data) {
            console.log(data);
            $("#response").text(data);
        });

    });
 