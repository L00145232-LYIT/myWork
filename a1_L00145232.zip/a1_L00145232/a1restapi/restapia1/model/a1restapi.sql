-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2022 at 02:11 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `a1restapi`
--
DROP DATABASE IF EXISTS a1restapi;

CREATE DATABASE a1restapi;

USE a1restapi;

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `teamcode` varchar(3) NOT NULL,
  `name` varchar(16) NOT NULL,
  `stadium` varchar(28) NOT NULL,
  `capacity` int(11) NOT NULL,
  `latitude` decimal(7,4) NOT NULL,
  `longitude` decimal(9,6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`teamcode`, `name`, `stadium`, `capacity`, `latitude`, `longitude`) VALUES
('ARS', 'Arsenal', 'Emirates Stadium', 60361, '51.5549', '-0.108436'),
('AST', 'Aston Villa', 'Villa Park', 42788, '52.5092', '-1.885080'),
('BIR', 'Birmingham', 'St Andrews', 30009, '52.4756', '-1.868240'),
('BLL', 'Blackpool', 'Bloomfield Road', 16220, '53.8046', '-3.048340'),
('BLN', 'Blackburn', 'Ewood Park', 31154, '53.7286', '-2.489370'),
('BOL', 'Bolton', 'University of Bolton Stadium', 28723, '53.5805', '-2.535710'),
('BOU', 'Bournemouth', 'Seward Stadium', 10700, '50.7352', '-1.838390'),
('BRI', 'Brighton', 'Amex Stadium', 22374, '50.8609', '-0.080140'),
('BUR', 'Burnley', 'Turf Moor', 22546, '53.7888', '-2.230180'),
('CAR', 'Cardiff', 'Cardiff City Stadium', 26828, '51.4729', '-3.204130'),
('CHE', 'Chelsea', 'Stamford Bridge', 41837, '51.4816', '-0.191034'),
('CRY', 'Crystal Palace', 'Selhurst Park', 26309, '51.3983', '-0.085455'),
('EVE', 'Everton', 'Goodison Park', 40157, '53.4387', '-2.966190'),
('FUL', 'Fulham', 'Craven Cottage', 25700, '51.4749', '-0.221619'),
('HUD', 'Huddersfield', 'The Galpharm Stadium', 24500, '53.6543', '-1.768370'),
('HUL', 'Hull', 'KC Stadium', 25586, '53.7465', '-0.368009'),
('LEI', 'Leicester', 'King Power Stadium', 32262, '52.6203', '-1.142170'),
('LIV', 'Liverpool', 'Anfield', 45522, '53.4308', '-2.960960'),
('MAN', 'Man United', 'Old Trafford', 75811, '53.4631', '-2.291390'),
('MCI', 'Man City', 'Etihad Stadium', 47805, '53.4830', '-2.200240'),
('MID', 'Middlesbrough', 'Riverside', 34988, '54.5781', '-1.217760'),
('NEW', 'Newcastle', 'St James Park', 52387, '54.9756', '-1.621790'),
('NOR', 'Norwich', 'Carrow Road', 27033, '52.6221', '1.309120'),
('QPR', 'QPR', 'Loftus Road', 18360, '51.5093', '-0.232204'),
('REA', 'Reading', 'Madjeski Stadium', 24161, '51.4222', '-0.982777'),
('SHE', 'Sheffield United', 'Bramall Lane', 32702, '53.3703', '-1.470830'),
('SOU', 'Southampton', 'St Mary\'s Stadium', 32689, '50.9058', '-1.391140'),
('STO', 'Stoke', 'Britannia Stadium', 27902, '52.9884', '-2.175420'),
('SUN', 'Sunderland', 'Stadium of Light', 49000, '54.9146', '-1.388370'),
('SWA', 'Swansea', 'Liberty Stadium', 20532, '51.6428', '-3.934730'),
('TOT', 'Tottenham', 'Tottenham Hotspur Stadium', 62303, '51.6044', '-0.066389'),
('WAT', 'Watford', 'Vicarage Road', 17477, '51.6498', '-0.401569'),
('WBA', 'West Brom', 'The Hawthorns', 26272, '52.5090', '-1.964180'),
('WHM', 'West Ham', 'Olympic Stadium', 60000, '51.5383', '-0.016587'),
('WIG', 'Wigan', 'DW Stadium', 25138, '53.5477', '-2.654150'),
('WOL', 'Wolves', 'Molineux', 27828, '52.5904', '-2.130610');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`teamcode`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
