var express = require("express");
var bodyParser = require("body-parser");
var cors = require("cors");
var model = require('./model/db.js');  //

var app = express();

// serves files in public folder
app.use(express.static('public'));
app.use(cors());
// NB:: this must be included to get JSON content sent with requests
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

///////////////////////////////////////////////////////////////////////////////////////////


//---------------TEAMS
app.route('/teams')
  .get(function (req, res) {
    res.status(200);
    model.getTeam(req, res);
    console.log(req.params.id);
  })
  .post(function (req, res) { // add
    // add solution here
  })
  .put(function (req, res) { // edit
    // add solution here
  })
  .delete(function (req, res) { // delete
    // add solution here
  });

var myServer = app.listen(3000, function () {
  console.log("Server listening on port 3000");
});
