<!-- front-page.php -->
<?php get_header();
echo the_meta(); ?>
<!-- deals and promotions -->
<div class="modal-body row">

    <div class="col-md-6">
        <ul>
            <h3 class="alert alert-success">Latest Deals</h3>
            <?php  // default loop
                  $deals = array(
                    'author_name'            => 'jameskelly',
                    'posts_per_page'         => '3',
                    'orderby'                => 'ASC',
                    'post_type'              => 'Deals'
                   );
                  $my_query = new WP_Query( $deals );
                    

                      if ( $my_query->have_posts() ) {
                        while ( $my_query->have_posts() ) {
                           $my_query->the_post();
                ?>
            <li><?php the_title(  ); echo " date : " ; the_time('Y.M' );
                      ?>
            </li>
            <?php

                    echo  wp_trim_words(  get_the_content( ), 20 ); ?>
            <a href="<?php echo the_permalink(  ) ;?>">read more</a>
            <?php
                      } // end while
                    } // end if
                    wp_reset_query();
                ?>
        </ul>
    </div>

    <div class="col-md-6">
        <ul>
            <h3 class="alert alert-warning">Promotions</h3>

            <?php  // default loop
                  $promotions = array(
                  	'author_name'            => 'jameskelly',
                  	'posts_per_page'         => '4',
                    'orderby'                => 'ASC',
                    'post_type'              => 'Promotions'
                   );
                  $my_query = new WP_Query( $promotions );
                     

                      if ( $my_query->have_posts() ) {
    	                  while ( $my_query->have_posts() ) {
    		                   $my_query->the_post();
                ?>
            <li><?php the_title(  ); echo " date : " ; the_time('Y.M' );
                      ?>
            </li>
            <?php

                    echo  wp_trim_words(  get_the_content( ), 20 ); ?>
            <a href="<?php echo the_permalink(  ) ;?>">read more</a>
            <?php
  	                  } // end while
                    } // end if
                    wp_reset_query();
                ?>
        </ul>
    </div>

</div><!-- end of row  -->

<!-- ---------------------------------------------------------------------------------------- -->

<?php get_footer(); ?>