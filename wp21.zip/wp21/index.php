<!-- front-page.php -->
<?php get_header();
echo the_meta(); ?>
<div class="modal-body row">
    <div class="col-md-6">
        <ul>
            <h3 class="alert alert-success">Latest Deals</h3>
            <?php  // default loop
                  $deals = array(
                    'author_name'            => 'jameskelly',
                    'posts_per_page'         => '3',
                    'orderby'                => 'ASC',
                    'post_type'              => 'Deals'
                   );
                  $my_query = new WP_Query( $deals );
                    

                      if ( $my_query->have_posts() ) {
                        while ( $my_query->have_posts() ) {
                           $my_query->the_post();
                ?>
            <li><?php the_title(  ); echo " date : " ; the_time('Y.M' );
                      ?>
            </li>
            <?php

                    echo  wp_trim_words(  get_the_content( ), 20 ); ?>
            <a href="<?php echo the_permalink(  ) ;?>">read more</a>
            <?php
                      } // end while
                    } // end if
                    wp_reset_query();
                ?>
        </ul>
    </div>
    <div class="col-md-6">
        <ul>
            <h3 class="alert alert-warning">Promotions</h3>

            <?php  // default loop
                  $promotions = array(
                  	'author_name'            => 'jameskelly',
                  	'posts_per_page'         => '4',
                    'orderby'                => 'ASC',
                    'post_type'              => 'Promotions'
                   );
                  $my_query = new WP_Query( $promotions );
                     

                      if ( $my_query->have_posts() ) {
    	                  while ( $my_query->have_posts() ) {
    		                   $my_query->the_post();
                ?>
            <li><?php the_title(  ); echo " date : " ; the_time('Y.M' );
                      ?>
            </li>
            <?php

                    echo  wp_trim_words(  get_the_content( ), 20 ); ?>
            <a href="<?php echo the_permalink(  ) ;?>">read more</a>
            <?php
  	                  } // end while
                    } // end if
                    wp_reset_query();
                ?>
        </ul>
    </div>
</div>
</div>
</div>
</div>
</div>
</div>
<?php
if (have_posts()) {

  //load posts loop
  while (have_posts()) {
      the_post();
     
      ?>
<div class="modal-body row">
    <div class="col-md-6">

        <?php
              echo "<h2> " . the_title() . "</h2>";
              echo "<br><h4>" . the_content() . "</h4><br>";
             ?> <a class="btn btn-primary" href="<?php echo the_permalink(); ?>" role="button">Read More..</a><br><?php
              echo "written by: ";
              echo the_author_posts_link()."<br>";
              ?>

    </div>

    <div class="col-md-6">
        <?php
              ?><html><img src="<?php echo get_theme_file_uri('assets/img/dublin.png') ?>" width="700" height="500"><?php
              ?>
    </div>

</div>

<?php 
  }
}
get_footer();


?>