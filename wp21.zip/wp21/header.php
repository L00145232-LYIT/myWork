<?php
wp_head();
?>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<!-- Navigation-->
<nav class="navbar navbar-expand-lg navbar-light" id="mainNav">
    <div class="container px-4 px-lg-5">
        <a class="navbar-brand" href="index.html">Irish Tourism</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive"
            aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            Menu
            <i class="fas fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ms-auto py-4 py-lg-0">
                <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="<?php echo site_url('/about')?>">About</a></li>
                <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="<?php echo site_url('/contact')?>">Contact</a></li>
                <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="<?php echo site_url('/sitemap')?>">Sitemap</a></li>
                <li class="nav-item"><a class="nav-link px-lg-3 py-3 py-lg-4" href="archive-dealPromotions.php">Deals & Promotions</a></li>
   

            </ul>
        </div>
    </div>
</nav>
<!-- Page Header-->
<!-- <header class="masthead"> -->



  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">

      <div class="item active">
        <img src="<?php echo get_theme_file_uri('assets/img/screenshot.png') ?>" alt="Donegal" style="width:200%; height: 80%;">
        <div class="carousel-caption">
          <h3>Donegal</h3>
          <p>Donegal is always so much fun!</p>
        </div>
      </div>

      <div class="item">
        <img src="<?php echo get_theme_file_uri('assets/img/aviva.png') ?>" alt="Dublin" style="width:200%; height: 80%;">
        <div class="carousel-caption">
          <h3>Dublin</h3>
          <p>Thank you, Dublin!</p>
        </div>
      </div>
    
      <div class="item">
        <img src="<?php echo get_theme_file_uri('assets/img/michael.png') ?>" alt="Kerry" style="width:200%; height: 80%;">
        <div class="carousel-caption">
          <h3>Kerry</h3>
          <p>We love Kerry!</p>
        </div>
      </div>
  
      <div class="item">
        <img src="<?php echo get_theme_file_uri('assets/img/mayo.png') ?>" alt="Mayo" style="width:200%; height: 80%;">
        <div class="carousel-caption">
          <h3>Mayo</h3>
          <p>Visit beautiful Mayo!</p>
        </div>
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>


</header>


<div class="modal-body row">
    <div class="col-md-8">

    </div>
    <div class="col-md-2">
        <select class="form-select" aria-label="Default select example">
            <option selected>Open this select menu</option>
            <option value="1">Dublin</option>
            <option value="2">Kerry</option>
            <option value="3">Mayo</option>
            <option value="4">Donegal</option>
        </select>
    </div>
    <div class="col-md-2">
        <input type="text" placeholder="Search..">
    </div>
</div>

<!-- <div class="page-heading"> -->

<!-- </div> -->