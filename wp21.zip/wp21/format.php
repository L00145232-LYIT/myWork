<!-- front-page.php -->
<?php get_header();
echo the_meta(); ?>
<!-- deals and promotions -->
<div class="modal-body row">

    <div class="col-md-6">
        <ul>
            <h3 class="alert alert-success">Latest Deals</h3>
            <?php  // default loop
                  $deals = array(
                    'author_name'            => 'jameskelly',
                    'posts_per_page'         => '3',
                    'orderby'                => 'ASC',
                    'post_type'              => 'Deals'
                   );
                  $my_query = new WP_Query( $deals );
                    

                      if ( $my_query->have_posts() ) {
                        while ( $my_query->have_posts() ) {
                           $my_query->the_post();
                ?>
            <li><?php the_title(  ); echo " date : " ; the_time('Y.M' );
                      ?>
            </li>
            <?php

                    echo  wp_trim_words(  get_the_content( ), 20 ); ?>
            <a href="<?php echo the_permalink(  ) ;?>">read more</a>
            <?php
                      } // end while
                    } // end if
                    wp_reset_query();
                ?>
        </ul>
    </div>

    <div class="col-md-6">
        <ul>
            <h3 class="alert alert-warning">Promotions</h3>

            <?php  // default loop
                  $promotions = array(
                  	'author_name'            => 'jameskelly',
                  	'posts_per_page'         => '4',
                    'orderby'                => 'ASC',
                    'post_type'              => 'Promotions'
                   );
                  $my_query = new WP_Query( $promotions );
                     

                      if ( $my_query->have_posts() ) {
    	                  while ( $my_query->have_posts() ) {
    		                   $my_query->the_post();
                ?>
            <li><?php the_title(  ); echo " date : " ; the_time('Y.M' );
                      ?>
            </li>
            <?php

                    echo  wp_trim_words(  get_the_content( ), 20 ); ?>
            <a href="<?php echo the_permalink(  ) ;?>">read more</a>
            <?php
  	                  } // end while
                    } // end if
                    wp_reset_query();
                ?>
        </ul>
    </div>

</div><!-- end of row  -->

<!-- ---------------------------------------------------------------------------------------- -->

<!-- dublin -->
<div class="modal-body row; border-top">

    <div class="col-md-6">
        <?php
           echo "<h1> Dublin </h1>";
           
        // the query
        $the_query = new WP_Query(array(
            'category_name' => 'Dublin',
            'post_status' => 'publish',
            'posts_per_page' => 2,
        ));
        ?>

        <?php if ($the_query->have_posts()) : ?>
        <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>

        <?php the_title(); ?>
        <?php the_content(); ?>

        <?php endwhile; ?>
        <?php wp_reset_postdata(); ?>

        <?php else : ?>
        <p><?php __('No News'); ?></p>
        <?php endif; ?>

    </div>
    <div class="col-md-6">
        <img src="<?php echo get_theme_file_uri('assets/img/aviva.png') ?>" width="700" height="500">
    </div>
</div><!-- end of row  -->
<!-- kerry -->
<div class="modal-body row; border-top">
    <div class="col-md-6">
        <img src="<?php echo get_theme_file_uri('assets/img/kerry.png') ?>" width="700" height="500">

    </div>
    <div class="col-md-6">
        <?php
     echo "<h1> Kerry </h1>";
      // the query
      $the_query = new WP_Query(array(
        'category_name' => 'Kerry',
        'post_status' => 'publish',
        'posts_per_page' => 2,
    ));
    ?>

        <?php if ($the_query->have_posts()) : ?>
        <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>

        <?php the_title(); ?>
        <?php the_content(); ?>

        <?php endwhile; ?>
        <?php wp_reset_postdata(); ?>

        <?php else : ?>
        <p><?php __('No News'); ?></p>
        <?php endif; ?>
    </div>
</div><!-- end of row  -->

<!-- ---------------------------------------------------------------------------------------- -->
<!-- mayo -->
<div class="modal-body row; border-top">
    <div class="col-md-6">
        <?php
     echo "<h1> Kerry </h1>";
      // the query
      $the_query = new WP_Query(array(
        'category_name' => 'Mayo',
        'post_status' => 'publish',
        'posts_per_page' => 2,
    ));
    ?>

        <?php if ($the_query->have_posts()) : ?>
        <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>

        <?php the_title(); ?>
        <?php the_content(); ?>

        <?php endwhile; ?>
        <?php wp_reset_postdata(); ?>

        <?php else : ?>
        <p><?php __('No News'); ?></p>
        <?php endif; ?>
    </div>
    <div class="col-md-6">
        <img src="<?php echo get_theme_file_uri('assets/img/Mayo.png') ?>" width="700" height="500">

    </div>
</div><!-- end of row  -->

<!-- ---------------------------------------------------------------------------------------- -->
<!-- donegal -->
<div class="modal-body row; border-top">

    <div class="col-md-6">
        <img src="<?php echo get_theme_file_uri('assets/img/donegal.png') ?>" width="700" height="500">
    </div>
    <div class="col-md-6">
        <?php
     echo "<h1> Kerry </h1>";
      // the query
      $the_query = new WP_Query(array(
        'category_name' => 'Donegal',
        'post_status' => 'publish',
        'posts_per_page' => 2,
    ));
    ?>

        <?php if ($the_query->have_posts()) : ?>
        <?php while ($the_query->have_posts()) : $the_query->the_post(); ?>

        <?php the_title(); ?>
        <?php the_content(); ?>

        <?php endwhile; ?>
        <?php wp_reset_postdata(); ?>

        <?php else : ?>
        <p><?php __('No News'); ?></p>
        <?php endif; ?>
    </div>
</div><!-- end of row  -->




<?php get_footer(); ?>