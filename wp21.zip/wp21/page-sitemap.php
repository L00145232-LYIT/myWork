<?php get_header();?>
<h1>Sitemap</h1>

<h2>Pages</h2>
<li><a href="<?php echo site_url('/about')?>">About Us</a></li>
<li><a href="<?php echo site_url('/contact')?>">Contact Page</a></li>


<h2>Posts</h2>
<h3>Dublin</h3>
<?php
   $the_query = new WP_Query(array(
    'category_name' => 'Dublin',
    'post_status' => 'publish',
    'posts_per_page' => 2,
));
?>

<?php if ($the_query->have_posts()) : ?>
<?php while ($the_query->have_posts()) : $the_query->the_post(); ?>

<li><a href="<?php echo the_permalink(  ) ;?>"><?php the_title(  );?></a></li>


<?php endwhile; ?>
<?php wp_reset_postdata(); ?>

<?php else : ?>
<p><?php __('No News'); ?></p>
<?php endif; ?>

<h3>Donegal</h3>
<?php
   $the_query = new WP_Query(array(
    'category_name' => 'Donegal',
    'post_status' => 'publish',
    'posts_per_page' => 2,
));
?>

<?php if ($the_query->have_posts()) : ?>
<?php while ($the_query->have_posts()) : $the_query->the_post(); ?>

<li><a href="<?php echo the_permalink(  ) ;?>"><?php the_title(  );?></a></li>


<?php endwhile; ?>
<?php wp_reset_postdata(); ?>

<?php else : ?>
<p><?php __('No News'); ?></p>
<?php endif; ?>

<h3>Kerry</h3>
<?php
   $the_query = new WP_Query(array(
    'category_name' => 'Kerry',
    'post_status' => 'publish',
    'posts_per_page' => 2,
));
?>

<?php if ($the_query->have_posts()) : ?>
<?php while ($the_query->have_posts()) : $the_query->the_post(); ?>

<li><a href="<?php echo the_permalink(  ) ;?>"><?php the_title(  );?></a></li>


<?php endwhile; ?>
<?php wp_reset_postdata(); ?>

<?php else : ?>
<p><?php __('No News'); ?></p>
<?php endif; ?>

<h3>Mayo</h3>
<?php
   $the_query = new WP_Query(array(
    'category_name' => 'Mayo',
    'post_status' => 'publish',
    'posts_per_page' => 2,
));
?>

<?php if ($the_query->have_posts()) : ?>
<?php while ($the_query->have_posts()) : $the_query->the_post(); ?>

<li><a href="<?php echo the_permalink(  ) ;?>"><?php the_title(  );?></a></li>


<?php endwhile; ?>
<?php wp_reset_postdata(); ?>

<?php else : ?>
<p><?php __('No News'); ?></p>
<?php endif; ?>


<h2>Deals</h2>
<ul>
    <?php  // default loop
                  $deals = array(
                    'author_name'            => 'jameskelly',
                    'posts_per_page'         => '3',
                    'orderby'                => 'ASC',
                    'post_type'              => 'Deals'
                   );
                  $my_query = new WP_Query( $deals );
                    

                      if ( $my_query->have_posts() ) {
                        while ( $my_query->have_posts() ) {
                           $my_query->the_post();
                ?>
    <li>

        <?php

                     ?>
        <a href="<?php echo the_permalink(  ) ;?>"><?php the_title(  );?></a>
    </li>
    <?php
                      } // end while
                    } // end if
                    wp_reset_query();
                ?>
</ul>
<h2>Promotions</h2>
<ul>
    <?php  // default loop
                  $promotions = array(
                    'author_name'            => 'jameskelly',
                    'posts_per_page'         => '3',
                    'orderby'                => 'ASC',
                    'post_type'              => 'Promotions'
                   );
                  $my_query = new WP_Query( $promotions );
                    

                      if ( $my_query->have_posts() ) {
                        while ( $my_query->have_posts() ) {
                           $my_query->the_post();
                ?>
    <li>

        <?php

                     ?>
        <a href="<?php echo the_permalink(  ) ;?>"><?php the_title(  );?></a>
    </li>
    <?php
                      } // end while
                    } // end if
                    wp_reset_query();
                ?>
</ul>
<?php get_footer();?>